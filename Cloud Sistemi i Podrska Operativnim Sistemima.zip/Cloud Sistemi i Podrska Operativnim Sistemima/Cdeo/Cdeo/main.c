#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Struktura za fajl (element jednostruko spregnute liste)
typedef struct File {
    char name[100];
    char content[500];
    struct File* next;
} File;

// Funkcija za dodavanje fajla u listu
File* addFile(File* head, char* name, char* content) {
    File* newFile = (File*)malloc(sizeof(File));
    if (newFile == NULL) {
        printf("Greska pri alokaciji memorije!\n");
        return head;
    }

    strcpy(newFile->name, name);
    strcpy(newFile->content, content);
    newFile->next = head;

    return newFile;
}

// Funkcija za "slanje" fajla (upis u datoteku)
void sendFile(File* file) {
    if (file == NULL) {
        printf("Nema fajla za slanje!\n");
        return;
    }

    FILE* f = fopen("GoogleDrive_sim.txt", "w");
    if (f == NULL) {
        printf("Greska pri otvaranju fajla za pisanje!\n");
        return;
    }

    fprintf(f, "Fajl: %s\nSadrzaj: %s\n", file->name, file->content);
    fclose(f);

    printf("Fajl \"%s\" poslat na Google Drive (simulacija).\n", file->name);
}

// Funkcija za citanje fajla
void readFileFromDrive() {
    FILE* f = fopen("GoogleDrive_sim.txt", "r");
    if (f == NULL) {
        printf("Greska pri otvaranju fajla za citanje!\n");
        return;
    }

    char buffer[600];
    printf("\nCitanje fajla sa Google Drive-a:\n");
    while (fgets(buffer, sizeof(buffer), f) != NULL) {
        printf("%s", buffer);
    }

    fclose(f);
}

int main() {
    File* head = NULL;

    // Dodavanje fajla u jednostruko spregnutu listu
    head = addFile(head, "primer.txt", "Ovo je sadrzaj fajla.");

    // Prolazak kroz listu i slanje fajla
    File* current = head;
    while (current != NULL) {
        sendFile(current);
        current = current->next;
    }

    // Citanje fajla iz datoteke
    readFileFromDrive();

    // Oslobadjanje memorije
    current = head;
    while (current != NULL) {
        File* temp = current;
        current = current->next;
        free(temp);
    }

    return 0;
}
