from pydrive.auth import GoogleAuth
from pydrive.drive import GoogleDrive

# Autentikacija
gauth = GoogleAuth()
gauth.LocalWebserverAuth()  
drive = GoogleDrive(gauth)

# Biramo fajl za upload
file_path = "test.txt"

# Kreiramo fajl
f = drive.CreateFile({'title': 'test.txt'})
f.SetContentFile(file_path)
f.Upload()

print("Fajl uspešno uploadovan na Google Drive!")
